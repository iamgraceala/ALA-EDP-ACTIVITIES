﻿Imports System.Data.Common
Imports MySql.Data.MySqlClient

Public Class Staff
    Private Sub BtnAddStaff_Click(sender As Object, e As EventArgs) Handles btnAddStaff.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "INSERT INTO salesstaff VALUES('" _
                & .TextStaffID.Text & "', '" _
                & .TextFname.Text & "','" _
                & .TextLastName.Text & "','" _
                & .TextStaffEmail.Text & "','" _
                & .TextStaffNumber.Text & "','" _
                & .TextVehicleSold.Text & "')"
                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Added")
                Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub
    Private Sub Clear_Boxes()
        TextStaffID.Text = ""
        TextFname.Text = ""
        TextLastName.Text = ""
        TextStaffEmail.Text = ""
        TextStaffNumber.Text = ""
        TextVehicleSold.Text = ""
    End Sub

    Private Sub UpdateStaff_Click(sender As Object, e As EventArgs) Handles UpdateStaff.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "UPDATE salesstaff SET FirstName =  '" _
            & .TextFname.Text & "', PhoneNumber = '" _
            & .TextStaffNumber.Text & "' WHERE StaffID = '" _
            & .TextStaffID.Text & "'"
                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Updated")
                Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub DeleteStaff_Click(sender As Object, e As EventArgs) Handles DeleteStaff.Click

        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "DELETE FROM salesstaff WHERE StaffID = '" _
            & .TextStaffID.Text & "'"
                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Deleted")
                Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With

    End Sub

    Private Sub LoadStaff_Click(sender As Object, e As EventArgs) Handles LoadStaff.Click
        Me.DataGridViewStaff.Rows.Clear()
        Dim strsql As String
        Dim mycommand As New MySqlCommand
        strsql = "SELECT * FROM salesstaff"
        Connect_to_DB()
        With mycommand
            .Connection = myconn
            .CommandType = CommandType.Text
            .CommandText = strsql
        End With
        Dim myreader As MySqlDataReader
        myreader = mycommand.ExecuteReader
        While myreader.Read()
            Me.DataGridViewStaff.Rows.Add(New Object() {myreader.Item("StaffID"), myreader.Item("FirstName"), myreader.Item("LastName"), myreader.Item("Email"), myreader.Item("PhoneNumber"), myreader.Item("VehiclesSold")})
        End While
        Disconnect_to_DB()
    End Sub

    Private Sub BackStaff_Click(sender As Object, e As EventArgs) Handles BackStaff.Click
        Hide()
        Form1.Show()
    End Sub

End Class