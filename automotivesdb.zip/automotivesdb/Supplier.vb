﻿Imports System.Data.Common
Imports MySql.Data.MySqlClient

Public Class Supplier
    Private Sub BtnAddSupplier_Click(sender As Object, e As EventArgs) Handles btnAddSupplier.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "INSERT INTO suppliers VALUES('" _
                & .TextSuppID.Text & "', '" _
                & .TextSuppName.Text & "','" _
                & .TextSuppEmail.Text & "','" _
                & .TextSuppContact.Text & "','" _
                & .TextSuppAddress.Text & "')"
                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Added")
                Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub Clear_Boxes()
        TextSuppID.Text = ""
        TextSuppName.Text = ""
        TextSuppEmail.Text = ""
        TextSuppContact.Text = ""
        TextSuppAddress.Text = ""
    End Sub

    Private Sub UpdateSupplier_Click(sender As Object, e As EventArgs) Handles UpdateSupplier.Click
        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "UPDATE suppliers SET SuppName =  '" _
            & .TextSuppName.Text & "', SupplierContact = '" _
            & .TextSuppContact.Text & "' WHERE SupplierID = " _
            & .TextSuppID.Text
                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Updated")
                Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With
    End Sub

    Private Sub DeleteSupplier_Click(sender As Object, e As EventArgs) Handles DeleteSupplier.Click

        With Me
            Call Connect_to_DB()
            Dim mycmd As New MySqlCommand
            Try
                strSQL = "DELETE FROM suppliers WHERE SupplierID = '" _
            & .TextSuppID.Text & "'"
                mycmd.CommandText = strSQL
                mycmd.Connection = myconn
                mycmd.ExecuteNonQuery()
                MsgBox("Record Successfully Deleted")
                Clear_Boxes()
            Catch ex As MySqlException
                MsgBox(ex.Number & " " & ex.Message)
            End Try
            Disconnect_to_DB()
        End With

    End Sub

    Private Sub LoadSupplier_Click(sender As Object, e As EventArgs) Handles LoadSupplier.Click
        Me.DataGridViewSupplier.Rows.Clear()
        Dim strsql As String
        Dim mycommand As New MySqlCommand
        strsql = "SELECT * FROM suppliers"
        Connect_to_DB()
        With mycommand
            .Connection = myconn
            .CommandType = CommandType.Text
            .CommandText = strsql
        End With
        Dim myreader As MySqlDataReader
        myreader = mycommand.ExecuteReader
        While myreader.Read()
            Me.DataGridViewSupplier.Rows.Add(New Object() {myreader.Item("SupplierID"), myreader.Item("SuppName"), myreader.Item("SupplierAddress"), myreader.Item("SupplierEmail"), myreader.Item("SupplierContact")})
        End While
        Disconnect_to_DB()
    End Sub

    Private Sub BackSupplier_Click(sender As Object, e As EventArgs) Handles BackSupplier.Click
        Hide()
        Form1.Show()
    End Sub
End Class
