﻿Imports System.IO
Imports MySql.Data.MySqlClient

Public Class Cars
    Private dt As DataTable

    Private Sub BackButton2_Click(sender As Object, e As EventArgs) Handles BackButton2.Click
        Hide()
        Form1.Show()
    End Sub

    Private Sub LoadButton_Click(sender As Object, e As EventArgs) Handles LoadButton.Click
        Dim filePath As String = ""

        ' Show the OpenFileDialog box
        If btnImport.ShowDialog() = DialogResult.OK Then
            filePath = btnImport.FileName
        End If

        ' Load the CSV file into a DataTable
        Dim dt As New DataTable()
        Using sr As New StreamReader(filePath)
            Dim headers() As String = sr.ReadLine().Split(","c)
            For i As Integer = 0 To headers.Length - 1
                Select Case i
                    Case 0
                        dt.Columns.Add("Serial No.")
                    Case 1
                        dt.Columns.Add("Unit")
                    Case 2
                        dt.Columns.Add("Model")
                    Case 3
                        dt.Columns.Add("Year")
                    Case 4
                        dt.Columns.Add("Color")
                    Case 5
                        dt.Columns.Add("Fuel Type")
                    Case 6
                        dt.Columns.Add("Type")
                    Case 7
                        dt.Columns.Add("Engine Size")
                    Case 8
                        dt.Columns.Add("Transmission Size")
                    Case 9
                        dt.Columns.Add("Price")
                End Select
            Next
            While Not sr.EndOfStream
                Dim rows() As String = sr.ReadLine().Split(","c)
                If rows.Length <= 10 Then
                    Dim newRow As DataRow = dt.NewRow()
                    For i As Integer = 0 To rows.Length - 1
                        newRow(i) = rows(i)
                    Next
                    dt.Rows.Add(newRow)
                End If
            End While
        End Using

        ' Bind the DataTable to the DataGridView
        DataGridViewCars.DataSource = dt
    End Sub



    Private Sub BackupButton_Click(sender As Object, e As EventArgs) Handles BackUpButton.Click
        ' Select the folder to save the backup file
        Dim folderBrowserDialog As New FolderBrowserDialog()
        If folderBrowserDialog.ShowDialog() = DialogResult.OK Then
            ' Construct the full path for the backup file
            Dim filePath As String = Path.Combine(folderBrowserDialog.SelectedPath, "backup.sql")

            ' Write the MySQL dump file
            Using sw As New StreamWriter(filePath)
                Dim connectionString As String = "Server=localhost;Port=3306;Database=automotivedb;Uid=root;Pwd=mgra;"
                Using conn As New MySqlConnection(connectionString)
                    conn.Open()
                    Using cmd As New MySqlCommand()
                        cmd.Connection = conn
                        cmd.CommandType = CommandType.Text
                        cmd.CommandText = "SELECT @@VERSION;"
                        Dim version As String = cmd.ExecuteScalar()
                        sw.WriteLine("-- MySQL dump " & version)
                        sw.WriteLine("-- Created on " & DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
                        sw.WriteLine("")
                        sw.WriteLine("USE automotivedb;")
                        sw.WriteLine("")
                        sw.WriteLine("DROP TABLE IF EXISTS `carsforsale`;")
                        sw.WriteLine("")
                        sw.WriteLine("CREATE TABLE `carsforsale` (")
                        sw.WriteLine("`Serial No.` int(11) NOT NULL AUTO_INCREMENT,")
                        sw.WriteLine("`Unit` varchar(50) NOT NULL,")
                        sw.WriteLine("`Model` varchar(50) NOT NULL,")
                        sw.WriteLine("`Year` int(11) NOT NULL,")
                        sw.WriteLine("`Color` varchar(50) NOT NULL,")
                        sw.WriteLine("`Fuel Type` varchar(50) NOT NULL,")
                        sw.WriteLine("`Type` varchar(50) NOT NULL,")
                        sw.WriteLine("PRIMARY KEY (`Serial No.`)")
                        sw.WriteLine(") ENGINE=InnoDB DEFAULT CHARSET=utf8;")
                        sw.WriteLine("")
                        Dim dt As DataTable = GetDataTable("SELECT * FROM `carsforsale`;", conn)
                        If dt IsNot Nothing Then
                            For Each row As DataRow In dt.Rows
                                Dim values As New List(Of String)()
                                For Each col As DataColumn In dt.Columns
                                    values.Add("'" & row(col.ColumnName).ToString().Replace("'", "''") & "'")
                                Next
                                sw.WriteLine("INSERT INTO `carsforsale` (" & String.Join(", ", dt.Columns.Cast(Of DataColumn).Select(Function(c) "`" & c.ColumnName & "`")) & ") VALUES (" & String.Join(", ", values) & ");")
                            Next
                        End If
                    End Using
                End Using
            End Using
            MessageBox.Show("Backup completed successfully.", "Backup", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Function GetDataTable(ByVal query As String, ByVal conn As MySqlConnection) As DataTable
        Dim dt As New DataTable()
        Using da As New MySqlDataAdapter(query, conn)
            da.Fill(dt)
        End Using
        Return dt
    End Function
End Class