﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Staff
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextVehicleSold = New System.Windows.Forms.TextBox()
        Me.LabelVehicleSold = New System.Windows.Forms.Label()
        Me.TextStaffNumber = New System.Windows.Forms.TextBox()
        Me.LabelStaffNumber = New System.Windows.Forms.Label()
        Me.TextStaffEmail = New System.Windows.Forms.TextBox()
        Me.LabelEmail = New System.Windows.Forms.Label()
        Me.DataGridViewStaff = New System.Windows.Forms.DataGridView()
        Me.StaffID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Email = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhoneNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VehiclesSold = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DeleteStaff = New System.Windows.Forms.Button()
        Me.UpdateStaff = New System.Windows.Forms.Button()
        Me.TextLastName = New System.Windows.Forms.TextBox()
        Me.LabelLastName = New System.Windows.Forms.Label()
        Me.TextFname = New System.Windows.Forms.TextBox()
        Me.TextStaffID = New System.Windows.Forms.TextBox()
        Me.LabelFname = New System.Windows.Forms.Label()
        Me.LabelStaff = New System.Windows.Forms.Label()
        Me.btnAddStaff = New System.Windows.Forms.Button()
        Me.LoadStaff = New System.Windows.Forms.Button()
        Me.BackStaff = New System.Windows.Forms.Button()
        Me.LoginStaffs = New System.Windows.Forms.Label()
        CType(Me.DataGridViewStaff, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextVehicleSold
        '
        Me.TextVehicleSold.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextVehicleSold.Location = New System.Drawing.Point(131, 295)
        Me.TextVehicleSold.Margin = New System.Windows.Forms.Padding(2)
        Me.TextVehicleSold.Name = "TextVehicleSold"
        Me.TextVehicleSold.Size = New System.Drawing.Size(212, 20)
        Me.TextVehicleSold.TabIndex = 62
        '
        'LabelVehicleSold
        '
        Me.LabelVehicleSold.AutoSize = True
        Me.LabelVehicleSold.BackColor = System.Drawing.Color.Transparent
        Me.LabelVehicleSold.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelVehicleSold.Location = New System.Drawing.Point(42, 297)
        Me.LabelVehicleSold.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelVehicleSold.Name = "LabelVehicleSold"
        Me.LabelVehicleSold.Size = New System.Drawing.Size(66, 14)
        Me.LabelVehicleSold.TabIndex = 61
        Me.LabelVehicleSold.Text = "Vehicle Sold"
        '
        'TextStaffNumber
        '
        Me.TextStaffNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextStaffNumber.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextStaffNumber.Location = New System.Drawing.Point(131, 264)
        Me.TextStaffNumber.Margin = New System.Windows.Forms.Padding(2)
        Me.TextStaffNumber.Name = "TextStaffNumber"
        Me.TextStaffNumber.Size = New System.Drawing.Size(212, 22)
        Me.TextStaffNumber.TabIndex = 60
        '
        'LabelStaffNumber
        '
        Me.LabelStaffNumber.AutoSize = True
        Me.LabelStaffNumber.BackColor = System.Drawing.Color.Transparent
        Me.LabelStaffNumber.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelStaffNumber.Location = New System.Drawing.Point(42, 266)
        Me.LabelStaffNumber.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelStaffNumber.Name = "LabelStaffNumber"
        Me.LabelStaffNumber.Size = New System.Drawing.Size(87, 14)
        Me.LabelStaffNumber.TabIndex = 59
        Me.LabelStaffNumber.Text = "Contact Number"
        '
        'TextStaffEmail
        '
        Me.TextStaffEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextStaffEmail.Location = New System.Drawing.Point(131, 231)
        Me.TextStaffEmail.Margin = New System.Windows.Forms.Padding(2)
        Me.TextStaffEmail.Name = "TextStaffEmail"
        Me.TextStaffEmail.Size = New System.Drawing.Size(212, 20)
        Me.TextStaffEmail.TabIndex = 58
        '
        'LabelEmail
        '
        Me.LabelEmail.AutoSize = True
        Me.LabelEmail.BackColor = System.Drawing.Color.Transparent
        Me.LabelEmail.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelEmail.Location = New System.Drawing.Point(42, 236)
        Me.LabelEmail.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelEmail.Name = "LabelEmail"
        Me.LabelEmail.Size = New System.Drawing.Size(35, 14)
        Me.LabelEmail.TabIndex = 57
        Me.LabelEmail.Text = "Email"
        '
        'DataGridViewStaff
        '
        Me.DataGridViewStaff.BackgroundColor = System.Drawing.Color.DarkOliveGreen
        Me.DataGridViewStaff.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DataGridViewStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewStaff.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StaffID, Me.FirstName, Me.LastName, Me.Email, Me.PhoneNumber, Me.VehiclesSold})
        Me.DataGridViewStaff.GridColor = System.Drawing.Color.RosyBrown
        Me.DataGridViewStaff.Location = New System.Drawing.Point(411, 137)
        Me.DataGridViewStaff.Name = "DataGridViewStaff"
        Me.DataGridViewStaff.Size = New System.Drawing.Size(639, 298)
        Me.DataGridViewStaff.TabIndex = 56
        '
        'StaffID
        '
        Me.StaffID.HeaderText = "Staff ID"
        Me.StaffID.Name = "StaffID"
        '
        'FirstName
        '
        Me.FirstName.HeaderText = "First Name"
        Me.FirstName.Name = "FirstName"
        '
        'LastName
        '
        Me.LastName.HeaderText = "Last Name"
        Me.LastName.Name = "LastName"
        '
        'Email
        '
        Me.Email.HeaderText = "Email"
        Me.Email.Name = "Email"
        '
        'PhoneNumber
        '
        Me.PhoneNumber.HeaderText = "Contact Number"
        Me.PhoneNumber.Name = "PhoneNumber"
        '
        'VehiclesSold
        '
        Me.VehiclesSold.HeaderText = "Vehicle Sold"
        Me.VehiclesSold.Name = "VehiclesSold"
        '
        'DeleteStaff
        '
        Me.DeleteStaff.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.DeleteStaff.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.DeleteStaff.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteStaff.ForeColor = System.Drawing.Color.Snow
        Me.DeleteStaff.Location = New System.Drawing.Point(174, 422)
        Me.DeleteStaff.Margin = New System.Windows.Forms.Padding(2)
        Me.DeleteStaff.Name = "DeleteStaff"
        Me.DeleteStaff.Size = New System.Drawing.Size(130, 33)
        Me.DeleteStaff.TabIndex = 55
        Me.DeleteStaff.Text = "Delete Record"
        Me.DeleteStaff.UseVisualStyleBackColor = False
        '
        'UpdateStaff
        '
        Me.UpdateStaff.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.UpdateStaff.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.UpdateStaff.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateStaff.ForeColor = System.Drawing.Color.Snow
        Me.UpdateStaff.Location = New System.Drawing.Point(174, 376)
        Me.UpdateStaff.Margin = New System.Windows.Forms.Padding(2)
        Me.UpdateStaff.Name = "UpdateStaff"
        Me.UpdateStaff.Size = New System.Drawing.Size(130, 33)
        Me.UpdateStaff.TabIndex = 54
        Me.UpdateStaff.Text = "Update Record"
        Me.UpdateStaff.UseVisualStyleBackColor = False
        '
        'TextLastName
        '
        Me.TextLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextLastName.Location = New System.Drawing.Point(131, 200)
        Me.TextLastName.Margin = New System.Windows.Forms.Padding(2)
        Me.TextLastName.Name = "TextLastName"
        Me.TextLastName.Size = New System.Drawing.Size(212, 20)
        Me.TextLastName.TabIndex = 53
        '
        'LabelLastName
        '
        Me.LabelLastName.AutoSize = True
        Me.LabelLastName.BackColor = System.Drawing.Color.Transparent
        Me.LabelLastName.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelLastName.Location = New System.Drawing.Point(42, 200)
        Me.LabelLastName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelLastName.Name = "LabelLastName"
        Me.LabelLastName.Size = New System.Drawing.Size(60, 14)
        Me.LabelLastName.TabIndex = 52
        Me.LabelLastName.Text = "Last Name"
        '
        'TextFname
        '
        Me.TextFname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextFname.Location = New System.Drawing.Point(131, 168)
        Me.TextFname.Margin = New System.Windows.Forms.Padding(2)
        Me.TextFname.Name = "TextFname"
        Me.TextFname.Size = New System.Drawing.Size(212, 20)
        Me.TextFname.TabIndex = 51
        '
        'TextStaffID
        '
        Me.TextStaffID.BackColor = System.Drawing.SystemColors.Window
        Me.TextStaffID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextStaffID.Location = New System.Drawing.Point(131, 137)
        Me.TextStaffID.Margin = New System.Windows.Forms.Padding(2)
        Me.TextStaffID.Name = "TextStaffID"
        Me.TextStaffID.Size = New System.Drawing.Size(212, 20)
        Me.TextStaffID.TabIndex = 50
        '
        'LabelFname
        '
        Me.LabelFname.AutoSize = True
        Me.LabelFname.BackColor = System.Drawing.Color.Transparent
        Me.LabelFname.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelFname.Location = New System.Drawing.Point(42, 170)
        Me.LabelFname.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelFname.Name = "LabelFname"
        Me.LabelFname.Size = New System.Drawing.Size(62, 14)
        Me.LabelFname.TabIndex = 49
        Me.LabelFname.Text = "First Name"
        '
        'LabelStaff
        '
        Me.LabelStaff.AutoSize = True
        Me.LabelStaff.BackColor = System.Drawing.Color.Transparent
        Me.LabelStaff.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelStaff.Location = New System.Drawing.Point(42, 139)
        Me.LabelStaff.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.LabelStaff.Name = "LabelStaff"
        Me.LabelStaff.Size = New System.Drawing.Size(44, 14)
        Me.LabelStaff.TabIndex = 48
        Me.LabelStaff.Text = "Staff ID"
        '
        'btnAddStaff
        '
        Me.btnAddStaff.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.btnAddStaff.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAddStaff.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddStaff.ForeColor = System.Drawing.Color.Snow
        Me.btnAddStaff.Location = New System.Drawing.Point(174, 329)
        Me.btnAddStaff.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAddStaff.Name = "btnAddStaff"
        Me.btnAddStaff.Size = New System.Drawing.Size(130, 33)
        Me.btnAddStaff.TabIndex = 47
        Me.btnAddStaff.Text = "Add Record"
        Me.btnAddStaff.UseVisualStyleBackColor = False
        '
        'LoadStaff
        '
        Me.LoadStaff.Location = New System.Drawing.Point(754, 453)
        Me.LoadStaff.Name = "LoadStaff"
        Me.LoadStaff.Size = New System.Drawing.Size(75, 23)
        Me.LoadStaff.TabIndex = 74
        Me.LoadStaff.Text = "Load Data"
        Me.LoadStaff.UseVisualStyleBackColor = True
        '
        'BackStaff
        '
        Me.BackStaff.Location = New System.Drawing.Point(639, 453)
        Me.BackStaff.Name = "BackStaff"
        Me.BackStaff.Size = New System.Drawing.Size(75, 23)
        Me.BackStaff.TabIndex = 73
        Me.BackStaff.Text = "Back"
        Me.BackStaff.UseVisualStyleBackColor = True
        '
        'LoginStaffs
        '
        Me.LoginStaffs.AutoSize = True
        Me.LoginStaffs.BackColor = System.Drawing.Color.Transparent
        Me.LoginStaffs.Font = New System.Drawing.Font("Cooper Black", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoginStaffs.ForeColor = System.Drawing.Color.DarkGreen
        Me.LoginStaffs.Location = New System.Drawing.Point(607, 78)
        Me.LoginStaffs.Name = "LoginStaffs"
        Me.LoginStaffs.Size = New System.Drawing.Size(265, 36)
        Me.LoginStaffs.TabIndex = 75
        Me.LoginStaffs.Text = "SALES STAFFS"
        '
        'Staff
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.StartHereDemo2.My.Resources.Resources.bg3
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1115, 585)
        Me.Controls.Add(Me.LoginStaffs)
        Me.Controls.Add(Me.LoadStaff)
        Me.Controls.Add(Me.BackStaff)
        Me.Controls.Add(Me.TextVehicleSold)
        Me.Controls.Add(Me.LabelVehicleSold)
        Me.Controls.Add(Me.TextStaffNumber)
        Me.Controls.Add(Me.LabelStaffNumber)
        Me.Controls.Add(Me.TextStaffEmail)
        Me.Controls.Add(Me.LabelEmail)
        Me.Controls.Add(Me.DataGridViewStaff)
        Me.Controls.Add(Me.DeleteStaff)
        Me.Controls.Add(Me.UpdateStaff)
        Me.Controls.Add(Me.TextLastName)
        Me.Controls.Add(Me.LabelLastName)
        Me.Controls.Add(Me.TextFname)
        Me.Controls.Add(Me.TextStaffID)
        Me.Controls.Add(Me.LabelFname)
        Me.Controls.Add(Me.LabelStaff)
        Me.Controls.Add(Me.btnAddStaff)
        Me.DoubleBuffered = True
        Me.Name = "Staff"
        Me.Text = "Staff"
        CType(Me.DataGridViewStaff, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextVehicleSold As TextBox
    Friend WithEvents LabelVehicleSold As Label
    Friend WithEvents TextStaffNumber As TextBox
    Friend WithEvents LabelStaffNumber As Label
    Friend WithEvents TextStaffEmail As TextBox
    Friend WithEvents LabelEmail As Label
    Friend WithEvents DataGridViewStaff As DataGridView
    Friend WithEvents StaffID As DataGridViewTextBoxColumn
    Friend WithEvents FirstName As DataGridViewTextBoxColumn
    Friend WithEvents LastName As DataGridViewTextBoxColumn
    Friend WithEvents Email As DataGridViewTextBoxColumn
    Friend WithEvents PhoneNumber As DataGridViewTextBoxColumn
    Friend WithEvents VehiclesSold As DataGridViewTextBoxColumn
    Friend WithEvents DeleteStaff As Button
    Friend WithEvents UpdateStaff As Button
    Friend WithEvents TextLastName As TextBox
    Friend WithEvents LabelLastName As Label
    Friend WithEvents TextFname As TextBox
    Friend WithEvents TextStaffID As TextBox
    Friend WithEvents LabelFname As Label
    Friend WithEvents LabelStaff As Label
    Friend WithEvents btnAddStaff As Button
    Friend WithEvents LoadStaff As Button
    Friend WithEvents BackStaff As Button
    Friend WithEvents LoginStaffs As Label
End Class
